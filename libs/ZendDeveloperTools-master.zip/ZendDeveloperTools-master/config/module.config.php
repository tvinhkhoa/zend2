<?php
return [
    'view_manager' => [
        'template_path_stack' => [
            'zenddevelopertools' => __DIR__ . '/../view',
        ],
    ],
];
