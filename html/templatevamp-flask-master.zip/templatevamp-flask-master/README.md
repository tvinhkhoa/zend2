templatevamp-flask
==================

Original
--------

TemplateVamp is a free Twitter Bootstrap admin template.

It was originally posted on the EGrappler site by Sarfraz on 2nd September 2013.

Available from here http://www.egrappler.com/templatevamp-free-twitter-bootstrap-admin-template/


Flask + Jinja2 converstion
--------------------------

I converted the demo site to use Jinja2 templates and made it available here.